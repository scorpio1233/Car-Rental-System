/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Rcar_package;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author User
 */
public class DataDisplay{

    private String carInfo, FileName, FileDirectory = "Data";

    //constructor(s)
    public DataDisplay() {
    }

    public DataDisplay(String dir, String name) {
        this.FileName = name;
        this.FileDirectory = dir;
    }

    public DataDisplay(String dir) {
        this.FileDirectory = dir;
    }

    //Fill table with text file data
    public void filltable(javax.swing.JTable table) {
        File file = new File(FileDirectory, FileName);
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            DefaultTableModel model = (DefaultTableModel) table.getModel();
            model.setRowCount(0);
            Object[] tableobjects = br.lines().toArray();
            for (Object tableobject : tableobjects) {
                String line = tableobject.toString().trim();
                if (!(line.isEmpty())) {
                    String[] rowdata = line.split(":");
                    if (rowdata[11].equals("available")) {
                        model.addRow(rowdata);
                    }
                }
            }
            br.close();
        } catch (IOException e) {
            System.out.println("No record found.");
        }
    }

    //Fill table with filtered data
    public void conditionalfill(javax.swing.JTable table, int index, String sample) {
        File file = new File(FileDirectory, FileName);
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            DefaultTableModel model = (DefaultTableModel) table.getModel();
            Object[] tableobjects = br.lines().toArray();
            for (Object tableobject : tableobjects) {
                String line = tableobject.toString().trim();
                if (!line.isEmpty()) {
                    String[] rowdata = line.split(":");
                    if (rowdata[11].equals("available") && rowdata[index].equalsIgnoreCase(sample)) {
                        model.addRow(rowdata);
                    }
                }
            }
            br.close();
        } catch (IOException e) {
            System.out.println(e);
        }
    }

    //find car details with carid
    public String findCar(String carid) throws FileNotFoundException, IOException {
        try ( BufferedReader contents = new BufferedReader(new FileReader("Data\\Cars.txt"))) {
            String record;
            while ((record = contents.readLine()) != null) {
                String[] details = record.split(":");
                if (details[0].equals(carid)) {
                    this.carInfo = record;
                }
            }
            contents.close();
        }
        return carInfo;
    }
    
    //fill table with history
    public void fillHistory(javax.swing.JTable table, int index, String username) {
        File file = new File(FileDirectory, FileName);
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            DefaultTableModel model = (DefaultTableModel) table.getModel();
            Object[] tableobjects = br.lines().toArray();
            for (Object tableobject : tableobjects) {
                String line = tableobject.toString().trim();
                if (!line.isEmpty()) {
                    String[] rowdata = line.split("#");
                    if (rowdata[index].equalsIgnoreCase(username)) {
                        model.addRow(rowdata);
                    }
                }
            }
            br.close();
        } catch (IOException e) {
            System.out.println(e);
        }
    }
    
    //find number of history of a username
    public String countHistory(String username) throws FileNotFoundException, IOException {
        int lines=0;
        String count;
        try ( BufferedReader contents = new BufferedReader(new FileReader("Data\\History.txt"))) {
            String record;
            while ((record = contents.readLine()) != null) {
                String[] details = record.split("#");
                if (details[0].equals(username)) {
                    lines ++;
                   
                }
            }
            count = lines+"";
            contents.close();
        }
        return count;
    }

}
