/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Rcar_package;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author User
 */
public class Log {
    
    private String generatedatetime() {
        LocalDateTime DateNow = LocalDateTime.now();
        DateTimeFormatter Format = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
        String DateTime = DateNow.format(Format);
        return DateTime;
    }
    
    public void Logging(String usernm, String action, String filename) {
        try {
            File file = new File("Data", filename);
            FileWriter fw = new FileWriter(file, true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw = new PrintWriter(bw);
            pw.write(usernm + "," + action + "," + generatedatetime());
            bw.newLine();
            pw.close();
            bw.close();
            fw.close();
        } catch (IOException e) {
            System.out.println(e);
        }
    }
    
}
