/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Rcar_package;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author User
 */
public class BookingRecord extends BookConfirm implements writeBooking {
    
    private boolean availability;

    public BookingRecord() {

    }
    
    public BookingRecord(String carid, boolean availability) {
        this.carid = carid;
        this.availability = availability;
    }

    public BookingRecord(String usernm, String carid) {
        this.usernm = usernm;
        this.carid = carid;
    }

    //initiate booking record: pending
    @Override
    public void writeBook() {
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        try ( BufferedWriter contents = new BufferedWriter(new FileWriter("Data\\Booking.txt", true))) {
            SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy.HH:mm:ss");
            Instant start = Instant.now();
            String timeStamp = df.format(new Date());
            String record = usernm + "#" + carid + "#" + timeStamp + "#pending#"+start+"\n";

            contents.write(record);
            contents.close();

        } catch (IOException ex) {
            Logger.getLogger(BookingRecord.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    //find car booking status
    public String findstatus(String usernm) throws FileNotFoundException, IOException {
        String status = "empty";
        try ( BufferedReader contents = new BufferedReader(new FileReader("Data\\Booking.txt"))) {
            String record;
            while ((record = contents.readLine()) != null) {
                String[] details = record.split("#");
                if (details[0].equals(usernm)) {
                    status = details[3];
                }
            }
            contents.close();

        }
        return status;

    }

    //find car id booked by username
    public String findcarid(String usernm) throws FileNotFoundException, IOException {
        try ( BufferedReader contents = new BufferedReader(new FileReader("Data\\Booking.txt"))) {
            String record;
            while ((record = contents.readLine()) != null) {
                String[] details = record.split("#");
                if (details[0].equals(usernm)) {
                    carid = details[1];
                }
            }
            contents.close();

        }
        return carid;
    }

    //find booking details using username
    public String findBooking(String usernm) throws FileNotFoundException, IOException {
        String record;
        try ( BufferedReader contents = new BufferedReader(new FileReader("Data\\Booking.txt"))) {

            while ((record = contents.readLine()) != null) {
                String[] details = record.split("#");
                if (details[0].equals(usernm)) {
                    return record;
                }
            }
            contents.close();

        }
        return record;

    }
    
    //confirmed booking, change car status
    @Override
    public void updateCar() {
        String status;
        if (availability == true){
            status = "available";
        }else{
            status = "not available";
        }
        String tempfilename = "temp.txt";
        File oldfile = new File("Data\\Cars.txt");
        File newfile = new File("Data", tempfilename);
        String line, data[];
        try {
            //read old file but write to new file
            FileWriter fw = new FileWriter(newfile, true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw = new PrintWriter(bw);
            FileReader fr = new FileReader(oldfile);
            BufferedReader br = new BufferedReader(fr);

            while ((line = br.readLine()) != null) {
                data = line.split(":");
                //not the carid,copy old data
                if (!(data[0].equals(this.carid))) {
                    pw.println(line);
                } else {
                    //write new data if the username found 
                    String newdata = data[0]+":"+data[1]+":"+data[2]+":"+data[3]+":"+data[4]+":"+data[5]+":"+data[6]+":"+data[7]+":"+
                            data[8]+":"+data[9]+":"+data[10]+":"+status+":"+data[12];
                    pw.println(newdata);
                }
            }

            pw.flush();
            pw.close();
            fr.close();
            br.close();
            bw.close();
            fw.close();
            oldfile.delete();
            File rename = new File("Data\\Cars.txt");
            newfile.renameTo(rename);

        } catch (IOException e) {
            System.out.println(e);
        }
    }
    
    
    public void PaymentMade(String usernm){
        String tempfilename = "temp.txt";
        File oldfile = new File("Data\\Booking.txt");
        File newfile = new File("Data", tempfilename);
        String line, data[];
        try {
            //read old file but write to new file
            FileWriter fw = new FileWriter(newfile, true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw = new PrintWriter(bw);
            FileReader fr = new FileReader(oldfile);
            BufferedReader br = new BufferedReader(fr);

            while ((line = br.readLine()) != null) {
                data = line.split("#");
                //not the usernm,copy old data
                if (!(data[0].equals(usernm))) {
                    pw.println(line);
                } else {
                    //write nothing (delete record) if the username found
                }
            }

            pw.flush();
            pw.close();
            fr.close();
            br.close();
            bw.close();
            fw.close();
            oldfile.delete();
            File rename = new File("Data\\Booking.txt");
            newfile.renameTo(rename);

        } catch (IOException e) {
            System.out.println(e);
        }
    }
    
    public void writeHistory(String usernm, String carid, String start, String duration, double payment){
        File newfile = new File("Data\\History.txt");
        String record = usernm+"#"+carid+"#"+start+"#"+duration+"#"+payment;
        try {
            FileWriter fw = new FileWriter(newfile, true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw = new PrintWriter(bw);
            pw.write(record+"\n");

            pw.flush();
            pw.close();
            bw.close();
            fw.close();

            File rename = new File("Data\\Booking.txt");
            newfile.renameTo(rename);

        } catch (IOException e) {
            System.out.println(e);
        }
    }
    
}
