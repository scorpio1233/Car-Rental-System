/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Rcar_package;

/**
 *
 * @author See Ying
 */
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ReadRecord {

    public String ReacLastID() throws FileNotFoundException, IOException {
        int lines = 0;
        String count = null;
        try ( BufferedReader contents = new BufferedReader(new FileReader("Data\\Cars.txt"))) {
            String record;
            while ((record = contents.readLine()) != null) {
            lines ++;
            }
            contents.close();
        }
        count = lines+"";
        return count;
    }
}
