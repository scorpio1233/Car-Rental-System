/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Rcar_package;

import java.awt.Component;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author See Ying
 */
public class Cars {

    private DefaultTableModel model;
    private String CustomerName, BookingTime, Status;
    private String carid;
    private String updateBrand, updateModel, updateCarPlate, updateColor, updateYear, updateType, updateSeatingCapacity, updateGear, updateEngine, updatePrice;
    private int selectedRow;
    private boolean selected;
    private String replaceline1, line;
    private String CustomerName2, carid2, BookingTime2, Status2; //to compare with the ori
    private ArrayList<String> carremove = new ArrayList<>();
    private ArrayList<String> updatecar = new ArrayList<>();
    private String usernm, useric, userpass;
    private String picID = "";

    public Cars() {
    }

    //add info to txt file
    public void addCar(ArrayList<String> carinfo) throws IOException {

        FileWriter contents = new FileWriter("Data\\Cars.txt", true);
        ReadRecord car = new ReadRecord();
        int cars = Integer.parseInt(car.ReacLastID()) - 1;
        String number = "0";
        if (cars < 9 && cars > 0) {
            number = "00000" + cars;
        }
        if (cars > 10) {
            number = "0000" + cars;
        }
        if (cars > 100) {
            number = "000" + cars;
        }
        if (cars > 1000) {
            number = "00" + cars;
        }
        if (cars > 10000) {
            number = "0" + cars;
        }
        String record = number + ":" + carinfo.get(0) + ":" + carinfo.get(1) + ":" + carinfo.get(2) + ":" + carinfo.get(3) + ":" + carinfo.get(4) + ":" + carinfo.get(5) + ":" + carinfo.get(6) + ":" + carinfo.get(7) + ":" + carinfo.get(8) + ":" + carinfo.get(9) + ":available:" + ":" + carinfo.get(10) + "\n";
        contents.write(record);
        contents.close();
        Component rootPane = null;
        JOptionPane.showMessageDialog(rootPane, "Add Car Succesful");
    }

    //read data from txt file (Car)
    public ArrayList<String> readFile(String filePath) {

        File file = new File(filePath);
        ArrayList<String> arrInfo = new ArrayList<String>();
        if (file.exists()) {
            try {
                BufferedReader br = new BufferedReader(new FileReader(file));
                String line = br.readLine();
                while (line != null) {
                    arrInfo.add(line);

                    line = br.readLine();
                }
                br.close();
            } catch (IOException ex) {
                System.out.println("Error in closing the BufferedReader");
            }
        }

        return arrInfo;

    }

    //Show CustomersBooking table
    public DefaultTableModel showBookingTable(Object TblAdminApprove) {
        this.model = (DefaultTableModel) TblAdminApprove;
        this.model.setRowCount(0);
        //Read file
        String filepath = "Data\\Booking.txt";
        ArrayList<String> sy = new ArrayList<String>();
        sy = readFile(filepath);

        for (int i = 0; i < sy.size(); i++) {
            String[] splitted = sy.get(i).split("#");
            if (splitted[3].equals("pending")) {
                this.model.addRow(new Object[]{splitted[0], splitted[1], splitted[2], splitted[3]});
            }
        }

        return model;
    }

    //Data JTable Validation
    void TableValidation(Object table) {
        this.selectedRow = -1;
        this.selected = false;
        this.selectedRow = Integer.parseInt(table.toString());
        if (this.selectedRow == -1) { //if no selected row
            JOptionPane.showMessageDialog(null, "No Row Selected", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            this.selected = true;
        }
    }

    int getSelectedROw() {
        return selectedRow;
    }

    void setSelectedRow(int selectedRow) {
        this.selectedRow = selectedRow;
    }

    boolean getSelected() {
        return this.selected;
    }

    //Select to approve from table
    public void AdminApprove(Object CustomerName, Object carid, Object BookingTime, Object Status) {
        this.CustomerName = CustomerName.toString(); //Convert to String
        this.carid = carid.toString();
        this.BookingTime = BookingTime.toString();
        this.Status = Status.toString();
    }

    //Change Status to renting & Date to approve time
    public void readFileWithId(String filename) throws FileNotFoundException, IOException {
        File file = new File(filename); //read file
        if (file.exists()) {
            try {
                BufferedReader br = new BufferedReader(new FileReader(file));
                String line = br.readLine();
                while (line != null) {
                    String[] datastring = line.split("#");
                    if (datastring[0].equals(CustomerName)) {
                        DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy.HH:mm:ss")
                                .withZone(ZoneId.systemDefault()); //time format
                        Instant end = Instant.now();
                        //change status and time
                        replaceline1 = line.replaceAll("pending", "Renting").replaceAll(datastring[2], DATE_TIME_FORMATTER.format(new Date().toInstant())).replaceAll(datastring[4], end.toString()); //change status

                    }
                    line = br.readLine();
                }
                br.close();
            } catch (IOException ex) {
                System.out.println("Error");
            }
        }
        File removeDataFile = new File("removeFile.txt"); //change txt file info
        File tempFile = new File("Data\\Booking.txt");
        BufferedReader read = new BufferedReader(new FileReader("Data\\Booking.txt"));
        FileWriter writeData = new FileWriter("removeFile.txt", true);
        while ((line = read.readLine()) != null) {
            String[] values = line.split("#");
            this.CustomerName2 = values[0]; //this in this file only punya variable
            this.carid2 = values[1];
            this.BookingTime2 = values[2];
            this.Status2 = values[3];
            //when condition=true, write to temporary file
            if (!(this.CustomerName.equals(this.CustomerName2) && this.carid.equals(this.carid2) && this.BookingTime.equals(this.BookingTime2) && this.Status.equals(this.Status2))) {
                writeData.write(values[0] + "#" + values[1] + "#" + values[2] + "#" + values[3] + "#" + values[4] + "\n");
            } else {
                writeData.write(this.replaceline1 + "\n");
            }
        }
        writeData.close();
        read.close();
        tempFile.delete();
        removeDataFile.renameTo(tempFile);
    }

//Show Cars table
    public DefaultTableModel showTable(Object TblCar) {
        this.model = (DefaultTableModel) TblCar;
        this.model.setRowCount(0);
        //Read file
        String filepath = "Data\\Cars.txt";
        ArrayList<String> sy = new ArrayList<String>();
        sy = readFile(filepath);

        for (int i = 1; i < sy.size(); i++) {
            String[] splitted = sy.get(i).split(":");

            this.model.addRow(new Object[]{splitted[0], splitted[1], splitted[2], splitted[3], splitted[4], splitted[5], splitted[6], splitted[7], splitted[8], splitted[9], splitted[10], splitted[11], splitted[12]});
        }
        return model;

    }

    //Show Sales Report
    public DefaultTableModel showSalesReport(Object TblSales) {
        this.model = (DefaultTableModel) TblSales;
        this.model.setRowCount(0);
        //Read file
        String filepath = "Data\\History.txt";
        ArrayList<String> sy = new ArrayList<String>();
        sy = readFile(filepath);

        for (int i = 0; i < sy.size(); i++) {
            String[] splitted = sy.get(i).split(":");
            this.model.addRow(new Object[]{splitted[0], splitted[3]});
        }

        return model;
    }

    public void removeCars(Object carid) {
        this.carid = carid.toString();
    }

    //compare car data for remove car
    public void compareCar(ArrayList<String> Array) throws FileNotFoundException, IOException {
        PrintWriter Writer = new PrintWriter("Data\\Cars.txt"); //Delete all old data in the Carstxt file
        Writer.print("");
        Writer.close();
        FileWriter writerdata = new FileWriter("Data\\Cars.txt"); //Write new data from array to the Carstxt file
        for (String STR : Array) {
            String[] Values = STR.split(":");
            if (!this.carid.equals(Values[0])) {
                writerdata.write(STR + "\n");
            }
        }
        writerdata.close();
        Array.clear();
    }

    //textfield received data pass to method UpdateCarstxtData
    public void updateCar(String carid, String updateBrand, String updateModel, String updateCarPlate, String updateColor, Object updateYear, Object updateType, Object updateSeatingCapacity, Object updateGear, Object updateEngine, String updatePrice) {
        this.carid = carid;
        this.updateBrand = updateBrand;
        this.updateModel = updateModel;
        this.updateCarPlate = updateCarPlate;
        this.updateColor = updateColor;
        this.updateYear = updateYear.toString();
        this.updateType = updateType.toString();
        this.updateSeatingCapacity = updateSeatingCapacity.toString();
        this.updateGear = updateGear.toString();
        this.updateEngine = updateEngine.toString();
        this.updatePrice = updatePrice;

    }

    //Update Car page passed dataUpdateCar to txtFile
    public void UpdateCarstxtData(ArrayList<String> Array, String id) throws FileNotFoundException, IOException {
        PrintWriter Writer = new PrintWriter("Data\\Cars.txt"); //Delete all old data in the Carstxt file
        Writer.print("");
        Writer.close();
        FileWriter writerdata = new FileWriter("Data\\Cars.txt"); //Write new data from array to the Carstxt file
        for (String STR : Array) {
            String[] Values = STR.split(":");
            if (!this.carid.equals(Values[0])) {
                writerdata.write(STR + "\n");
            } else {
                writerdata.write(id + ":" + this.updateBrand + ":" + this.updateModel + ":" + this.updateCarPlate + ":" + this.updateColor + ":" + this.updateYear + ":" + this.updateType + ":" + this.updateSeatingCapacity + ":" + this.updateGear + ":" + this.updateEngine + ":" + this.updatePrice + ":" + Values[11] + ":" + Values[12] + "\n");

            }
        }
        writerdata.close();
        Array.clear();
    }

    //textfield received data pass to method UpdateProfile
    public void updateProfile(String usernm, String useric, String userpass) {
        this.usernm = usernm;
        this.useric = useric;
        this.userpass = userpass;
    }

    public void updateProfile(String usernm, String picID) {
        this.usernm = usernm;
        this.picID = picID;
    }

    //Update Profile data and passed to txtFile
    public void UpdateProfile(ArrayList<String> Array) throws FileNotFoundException, IOException {
        /*
        PrintWriter Writer = new PrintWriter("Data\\UserAcc.txt"); //Delete all old data in the Usertxt file
        Writer.print(""); //print blank
        Writer.close();
*/
        FileWriter writerdata = new FileWriter("Data\\UserAcc.txt"); //Write new data from array to the Usertxt file
        for (String STR : Array) {
            String[] Values = STR.split(":");
            if (!this.usernm.equals(Values[0])) {
                writerdata.write(STR + "\n");
            } else if (!this.picID.equals("")) {
                writerdata.write(usernm + ":" + Values[1] + ":" + Values[2] + ":" + Values[3] + ":" + Values[4] + ":" + Values[5] + ":" + this.picID + "\n");
            } else {
                writerdata.write(usernm + ":" + this.userpass + ":" + this.useric + ":" + Values[3] + ":" + Values[4] + ":" + Values[5] + ":" + Values[6] + "\n");

            }
        }
        writerdata.close();
        Array.clear();
    }

    ArrayList<String> getupdateCar() {
        return this.updatecar;
    }

    public String getCarid() {
        return carid;
    }

    private void dispose() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
