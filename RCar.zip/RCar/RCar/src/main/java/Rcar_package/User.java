/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Rcar_package;

/**
 *
 * @author User
 */
public class User {

    private String usernm, password, type;

    public User() {
    }
    
    public User(String name, String password) {
        this.usernm = name;
        this.password = password;
    }

    public User(String name, String password, String type) {
        this.usernm = name;
        this.password = password;
        this.type = type;
    }

    public String getName() {
        return usernm;
    }

    public void setName(String name) {
        this.usernm = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return usernm + "," + password + "," + type;
    }
}
