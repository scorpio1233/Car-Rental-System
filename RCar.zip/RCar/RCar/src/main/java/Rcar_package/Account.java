/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Rcar_package;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author User
 */
public class Account extends User {

    private String usernm, password, ic;

    public Account() {
    }

    public Account(String usernm) {
        this.usernm = usernm;
    }

    public Account(String usernm, String password) {
        this.usernm = usernm;
        this.password = password;
    }

    public String getUsernm() {
        return usernm;
    }

    public void setUsernm(String usernm) {
        this.usernm = usernm;
    }

    @Override
    public String getPassword() {
        return password;
    }

    @Override
    public void setPassword(String password) {
        this.password = password;
    }

    //check username and password to login, if found record, return true
    public boolean login() throws FileNotFoundException, IOException {
        boolean login = false;
        try ( BufferedReader contents = new BufferedReader(new FileReader("Data\\UserAcc.txt"))) {
            String record;
            while ((record = contents.readLine()) != null) {
                String[] details = record.split(":");
                if (details[0].equals(this.usernm) && details[1].equals(this.password)) {
                    login = true;
                    this.usernm = details[0];
                    break;
                }
            }
            contents.close();
        }
        return login;
    }

    //check whether the account is admin
    public boolean admin() throws FileNotFoundException, IOException {
        boolean admin = false;
        try ( BufferedReader contents = new BufferedReader(new FileReader("Data\\UserAcc.txt"))) {
            String record;
            while ((record = contents.readLine()) != null) {
                String[] details = record.split(":");
                if (details[0].equals(this.usernm) && details[3].equalsIgnoreCase("admin")) {
                    admin = true;
                    break;
                }
            }
            contents.close();
        }
        return admin;
    }

    //check is the username registered, if the username already taken, return false
    public boolean register(String usernm) throws FileNotFoundException, IOException {
        boolean register = true;
        try ( BufferedReader contents = new BufferedReader(new FileReader("Data\\UserAcc.txt"))) {
            String record;
            while ((record = contents.readLine()) != null) {
                String[] details = record.split(":");
                if (details[0].equalsIgnoreCase(usernm)) {
                    register = false;
                    break;
                }
            }
            contents.close();
        }
        return register;
    }

    //find user password using username
    public String findpass(String usernm) throws FileNotFoundException, IOException {
        try ( BufferedReader contents = new BufferedReader(new FileReader("Data\\UserAcc.txt"))) {
            String record;
            while ((record = contents.readLine()) != null) {
                String[] details = record.split(":");
                if (details[0].equals(usernm)) {
                    this.password = details[1];
                }
            }
            contents.close();

        }
        return password;
    }

    //find user ic number using username
    public String findic(String usernm) throws FileNotFoundException, IOException {
        try ( BufferedReader contents = new BufferedReader(new FileReader("Data\\UserAcc.txt"))) {
            String record;
            while ((record = contents.readLine()) != null) {
                String[] details = record.split(":");
                if (details[0].equals(usernm)) {
                    this.ic = details[2];
                }
            }
            contents.close();

        }
        return ic;
    }

    //change password
    public void updatePass(String newdata) {
        String tempfilename = "temp.txt";
        File oldfile = new File("Data\\UserAcc.txt");
        File newfile = new File("Data", tempfilename);
        String line, data[];
        try {
            //read old file but write to new file
            FileWriter fw = new FileWriter(newfile, true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw = new PrintWriter(bw);
            FileReader fr = new FileReader(oldfile);
            BufferedReader br = new BufferedReader(fr);

            while ((line = br.readLine()) != null) {
                data = line.split(":");
                //not the usename,copy old data
                if (!(data[0].equals(usernm))) {
                    pw.println(line);
                } else {
                    //write new data if the username found 
                    pw.println(newdata);
                }
            }

            pw.flush();
            pw.close();
            fr.close();
            br.close();
            bw.close();
            fw.close();
            oldfile.delete();
            File rename = new File("Data\\UserAcc.txt");
            newfile.renameTo(rename);

        } catch (IOException e) {
            System.out.println(e);
        }
    }

    //add new customer account record
    public boolean addRec(String record) throws IOException {
        try ( BufferedWriter contents = new BufferedWriter(new FileWriter("Data\\UserAcc.txt", true))) {
            contents.write(record);
            contents.close();
            
        }
        return true;
    }
    
    //find user password and username using security question and ic
    public String checkPass(String ic, String QuesNum, String ans) throws FileNotFoundException, IOException {
        String found = null;
        try ( BufferedReader contents = new BufferedReader(new FileReader("Data\\UserAcc.txt"))) {
            
            String record;
            while ((record = contents.readLine()) != null) {
                String[] details = record.split(":");
                if (details[2].equals(ic)&&details[4].equals(QuesNum)&&details[5].equals(ans)) {
                    this.password = details[1];
                    this.usernm = details[0];
                    found = usernm+":"+password;
                }
            }
            contents.close();

        }
        return found;
    }

    //Polymorphism: Overriding toString method of class Account
    @Override
    public String toString() {
        return usernm + "," + password;
    }
}
